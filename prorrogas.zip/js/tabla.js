﻿ function tabla() {//evento para ocultar los div de los fórmularios

  //Se le da el attributo hiddenbyfilter a todas las filas de la tabla
    let rows = document.querySelectorAll("#table tr");
    for (let i = 0; i < rows.length; i++) {
        rows[i].setAttribute("hiddenByFilter", 0);
    }
    //Se asigna la funcion de filtrado al evento keyup 
    let input_1 = document.querySelector("#RadSap");
    input_1.addEventListener("keyup", filter);

    let input_2 = document.querySelector("#Ente");
    input_2.addEventListener("keyup", filter);

    let input_3 = document.querySelector("#fechSol");
    input_3.addEventListener("keyup", filter);

    let input_4 = document.querySelector("#dias");
    input_4.addEventListener("keyup", filter);

    let input_5 = document.querySelector("#venPror");
    input_5.addEventListener("keyup", filter);

    let input_6 = document.querySelector("#estSol");
    input_6.addEventListener("keyup", filter);
}

function filter() {
    //this -> corresponde al input en el cual se da el evento keyup
    //Valor del input
    let searchValue = this.value;
    //Listado de las filas de la tabla (tr)
    let rows = document.querySelectorAll("#table tr");
    //Indicador de que columna debe filtrar el input
    let filterForColumn = this.getAttribute("filterForColumn");

    for (let i = 0; i < rows.length; i++) {
        //Si la fila no tiene filtro o si el nuevo filtro tiene precedencia
        if (rows[i].getAttribute("hiddenByFilter") == 0 ||
            filterForColumn <= rows[i].getAttribute("hiddenByFilter")
        ) {
            //Se aplica filtro a la fila
            rows[i].setAttribute("hiddenByFilter", filterForColumn);
            //Se obtiene la celda (td)
            let cell = rows[i].querySelector("td:nth-child(" + filterForColumn + ")");
            //Si el texto de la celda es igual al buscado o si el valor buscado es vacio
            if (cell.innerText == searchValue || searchValue === "") {
                //Se quita el filtro de la fila
                rows[i].setAttribute("hiddenByFilter", 0);
            }
        }
    }
}
﻿
window.onload = function () {//evento para ocultar los div de los fórmularios
    divT = document.getElementById("fmrSF");
    divT.style.display = "none";
    divC = document.getElementById("fmrDp");
    divC.style.display = "none";
    divDF = document.getElementById("def");
    divDF.style.display = "none";
    document.getElementById("municipio").disabled = true;

    //Se le da el attributo hiddenbyfilter a todas las filas de la tabla
    //let rows = document.querySelectorAll("#table tr");
    //for (let i = 0; i < rows.length; i++) {
    //    rows[i].setAttribute("hiddenByFilter", 0);
    //}
    //Se asigna la funcion de filtrado al evento keyup 
    //let input_1 = document.querySelector("#RadSap");
    //input_1.addEventListener("keyup", filter);

    //let input_2 = document.querySelector("#Ente");
    //input_2.addEventListener("keyup", filter);

    //let input_3 = document.querySelector("#fechSol");
    //input_3.addEventListener("keyup", filter);

    //let input_4 = document.querySelector("#dias");
    //input_4.addEventListener("keyup", filter);

    //let input_5 = document.querySelector("#venPror");
    //input_5.addEventListener("keyup", filter);

    //let input_6 = document.querySelector("#estSol");
    //input_6.addEventListener("keyup", filter);
}

//function filter() {
//    //this -> corresponde al input en el cual se da el evento keyup
//    //Valor del input
//    let searchValue = this.value;
//    //Listado de las filas de la tabla (tr)
//    let rows = document.querySelectorAll("#table tr");
//    //Indicador de que columna debe filtrar el input
//    let filterForColumn = this.getAttribute("filterForColumn");

//    for (let i = 0; i < rows.length; i++) {
//        //Si la fila no tiene filtro o si el nuevo filtro tiene precedencia
//        if (rows[i].getAttribute("hiddenByFilter") == 0 ||
//            filterForColumn <= rows[i].getAttribute("hiddenByFilter")
//        ) {
//            //Se aplica filtro a la fila
//            rows[i].setAttribute("hiddenByFilter", filterForColumn);
//            //Se obtiene la celda (td)
//            let cell = rows[i].querySelector("td:nth-child(" + filterForColumn + ")");
//            //Si el texto de la celda es igual al buscado o si el valor buscado es vacio
//            if (cell.innerText == searchValue || searchValue === "") {
//                //Se quita el filtro de la fila
//                rows[i].setAttribute("hiddenByFilter", 0);
//            }
//        }
//    }
//}

function pagoOnChange(sel) {// al seleccionar un ente se activan los div
    if (sel.value == "DP") {
        divC = document.getElementById("fmrDp");
        divC.style.display = "";

        divT = document.getElementById("fmrSF");
        divT.style.display = "none";

        divDF = document.getElementById("def");
        divDF.style.display = "none";

    } else if (sel.value == "DF") {
        divC = document.getElementById("fmrDp");
        divC.style.display = "none";

        divT = document.getElementById("fmrSF");
        divT.style.display = "none";

        divDF = document.getElementById("def");
        divDF.style.display = "";

    }else if (sel.value == "SF") {
        divC = document.getElementById("fmrDp");
        divC.style.display = "none";

        divT = document.getElementById("fmrSF");
        divT.style.display = "";

        divDF = document.getElementById("def");
        divDF.style.display = "none";
    } else {
        divC = document.getElementById("fmrDp");
        divC.style.display = "none";

        divT = document.getElementById("fmrSF");
        divT.style.display = "none";

        divDF = document.getElementById("def");
        divDF.style.display = "none";
    }
}

//Guardar informacion de la solicitud de prorrogas de DP
jQuery(document).ready(function () {
    $('#guardarDp').click(function () {
        var radicadoOcho ="N/A";
        var radicadoTres = $('#radicadoDP').val();//Campo ingresado por el usuario
        var radicadoUno = "N/A";
        var ente = $('#ente').val();//Campo ingresado por el usuario
        var IdCliente = $('#identiDP').val();//Campo ingresado por el usuario
        var NombCliente = $('#nombCliDP').val();//Campo ingresado por el usuario
        var genero = $('#generoDP').val();//Campo ingresado por el usuario
        var medioEnvio = $('#medEnvioDP').val();//Campo ingresado por el usuario
        var direccion = $('#dirEnvDP').val();//Campo ingresado por el usuario
        var diasPro = $('#diasProDP').val();//Campo ingresado por el usuario
        var fechpro = $('#feProDP').val();//Campo ingresado por el usuario
        var radSuper = "N/A";
        var area = "N/A";
        var delegado = "N/A";
        var estado = "Solictud Prorroga";
        var municipio = $('#municipio').val();//Campo ingresado por el usuario
        var causal = $('#causaldp').val();//Campo ingresado por el usuario
        var mProrroga = $('#MsolPrDP').val();//Campo ingresado por el usuario
        var mreclamo = $('#MreclaDP').val();//Campo ingresado por el usuario
        
        if (genero == null || medioEnvio == null || direccion == "" || diasPro == "" || fechpro == "" || municipio == "" || causal ==null || mProrroga == "" || mreclamo == "") {           
            alert("Faltan campos por dilgenciar");
            $('#generoDP').css('border-color', 'Red');
            $('#medEnvioDP').css('border-color', 'Red');
            $('#dirEnvDP').css('border-color', 'Red');
            $('#diasProDP').css('border-color', 'Red');
            $('#municipio').css('border-color', 'Red');
            $('#causaldp').css('border-color', 'Red');
            $('#MreclaDP').css('border-color', 'Red');
            $('#MsolPrDP').css('border-color', 'Red');      
            $('#CondirEnvDP').css('border-color', 'Red');             
        } else {
            $('#generoDP').css('border-color', 'lightgrey');
            $('#medEnvioDP').css('border-color', 'lightgrey');
            $('#dirEnvDP').css('border-color', 'lightgrey');
            $('#diasProDP').css('border-color', 'lightgrey');
            $('#municipio').css('border-color', 'lightgrey');
            $('#causaldp').css('border-color', 'lightgrey');
            $('#MreclaDP').css('border-color', 'lightgrey');
            $('#MsolPrDP').css('border-color', 'lightgrey');
            $('#CondirEnvDP').css('border-color', 'lightgrey');    
       
            sendDataAjax(radicadoOcho, radicadoTres, radicadoUno, ente, IdCliente, NombCliente, genero, medioEnvio, direccion, diasPro, fechpro, radSuper, area, delegado, estado, municipio, causal, mProrroga, mreclamo);

            function sendDataAjax(radicadoOcho, radicadoTres, radicadoUno, ente, IdCliente, NombCliente, genero, medioEnvio, direccion, diasPro, fechpro, radSuper, area, delegado, estado, municipio, causal, mProrroga, mreclamo) {
                var actionData = "{'radicadoOcho': '" + radicadoOcho + "','radicadoTres': '" + radicadoTres + "','radicadoUno': '" + radicadoUno + "','ente': '" + ente + "','IdCliente': '" + IdCliente + "','NombCliente': '" + NombCliente + "','genero': '" + genero + "','medioEnvio': '" + medioEnvio + "','direccion': '" + direccion + "','diasPro': '" + diasPro + "','fechpro': '" + fechpro + "','radSuper':'" + radSuper + "','area': '" + area + "','delegado': '" + delegado + "','estado': '" + estado + "','municipio': '" + municipio + "','causal': '" + causal + "','mProrroga': '" + mProrroga + "','mreclamo': '" + mreclamo + "'} ";
                $.ajax(
                    {
                        url: "prorrogas.aspx/guardarDP",
                        data: actionData,
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        success: function (msg) { alert(msg.d); },
                        error: function (result) {
                            alert("ERRORES " + result.status + ' ' + result.statusText);
                        }
                    });
                document.getElementById("radicadoDP").value = "";
                document.getElementById("ente").value = "";
                document.getElementById("identiDP").value = "";
                document.getElementById("nombCliDP").value = "";
                document.getElementById("generoDP").value = "";
                document.getElementById("medEnvioDP").value = "";
                document.getElementById("dirEnvDP").value = "";                 
                document.getElementById("municipio").value = "";
                document.getElementById("CondirEnvDP").value = "";   
                document.getElementById("causaldp").value = "";
                document.getElementById("MreclaDP").value = "";
                document.getElementById("MsolPrDP").value = "";
                document.getElementById("diasProDP").value = "";
                document.getElementById("feProDP").value = "";                                             
            };
        }
    });
});

//buscar requerimiento 300
jQuery(document).ready(function () {
    $('#buscarDP').click(function () {
        var radicado = $('#radicadoDP').val()      
        if (radicado == "") {
            alert("Ingrese un número de Radicado");
            $('#radicadoDP').css('border-color', 'Red');
        } else {           
            $('#radicadoDP').css('border-color', 'lightgrey');
            radicado = JSON.stringify(radicado);
            $.ajax({
                url: "prorrogas.aspx/brtres",
                type: "GET",
                data: { "radicado": radicado },
                contentType: "application/json;charset=utf-8",
                dataType: "json",
                success: function (result) {
                    $.each(result, function (key,item) {
                        document.getElementById("nombCliDP").value = item.nombreCli;
                        document.getElementById("identiDP").value = item.cedula;                    
                    });
                },
                error: function (result) {
                    alert("Ha ocurrido un error" + result.statusText);
                }
            });
        }
    });  
});

//solo numeros
window.addEventListener("load", function () {
    //formulario de derechos
    fmlEntes.radicadoDP.addEventListener("keypress", soloNumeros, false);
    fmlEntes.diasProDP.addEventListener("keypress", soloNumeros, false);
    //formulario de defensor
    fmlEntes.radicadoDF.addEventListener("keypress", soloNumeros, false);
    //formulario de super
    fmlEntes.radicadoSp.addEventListener("keypress", soloNumeros, false);
});

//Solo permite introducir numeros.
function soloNumeros(e) {
    var key = window.event ? e.which : e.keyCode;
    if (key < 48 || key > 57) {
        e.preventDefault();
    }
}


//----------------------------------------------------------------------------------------------------------------------------------------------
//Validar Campos vacíos en el fomulario de derechos.
function validarDP() {
    var isValid = true;
    if ($('#Name').val().trim() == "") {
        $('#Name').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Name').css('border-color', 'lightgrey');
    }
    if ($('#Age').val().trim() == "") {
        $('#Age').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Age').css('border-color', 'lightgrey');
    }
    if ($('#State').val().trim() == "") {
        $('#State').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#State').css('border-color', 'lightgrey');
    }
    if ($('#Country').val().trim() == "") {
        $('#Country').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Country').css('border-color', 'lightgrey');
    }
    return isValid;
}

function validarDF() {
}
function validarSP() {
}


//limpiar cuadro de búsqueda
function limBusDP() {

}
function limBusDF() {

}

function limBusSP() {

}


//Funcion para validar la ortografía
function ortografia() {

}

//Funciones para calcular la fecha e
function fechasHabiles() {

}

//dias calendario
function sumDias(fecha, numDias) {
    fecha.setDate(fecha.getDate() + numDias);
    return fecha;
}

function sumDiasHabiles(fecha, numDias) {
    fecha.setDate(fecha.getDate() + numDias);
    return fecha;
}

$('#diasProDP').on('keyup', function () {
    var numDias = parseInt($('#diasProDP').val());
    if (isNaN(numDias)) {
        document.getElementById("feProDP").value = '';
        return;
    }
    var fechaActual = new Date();
    var fechaCalculada = sumDias(fechaActual, numDias);
    document.getElementById("feProDP").value = fechaCalculada.toLocaleDateString();
});

function email() {

}

// validar si medio de envio es fisico habilitar campo municipio 

$('#medEnvioDP').on('change', function () {
    var medEnvio = $('#medEnvioDP').val();

    if (medEnvio == "f") {
        document.getElementById("municipio").disabled = false;
    } else {
        document.getElementById("municipio").disabled = true;
    }
});
function medioEnvio() {

}

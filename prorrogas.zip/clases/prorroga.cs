﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace prorrogas.clases
{
    public class prorroga
    {
        public string radicadoOcho { get; set; }
        public string radicadoTres { get; set; }
        public string radicadoUno { get; set; }
        public string ente { get; set; }
        public string idCliente { get; set; }
        public string genero { get; set; }
        public string medioEnvio { get; set; }
        public string direccion { get; set; }
        public int diasPro { get; set; }
        public string fechaPro { get; set; }
        public string radSuper { get; set; }
        public string area { get; set; }
        public string delegado { get; set; }
        public string estado { get; set; }
    }
}
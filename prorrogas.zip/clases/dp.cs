﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace prorrogas.clases
{
    public class dp
    {
        public string nombreCli { get; set; }
        public string cedula { get; set; }
        public string genero { get; set; }
        public string medioEnvio { get; set; }
        public string direccion { get; set; }
        public string municipio { get; set; }
        public string causal { get; set; }
        public string motivoReclama { get; set; }
        public string motivoProrroga { get; set; }
        public int dias { get; set; }
        public string fecha { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.OleDb;
using System.Web;

namespace prorrogas.clases
{
    public class conectar
    {
        public conectar() { 
        string CadenaConexion;
        OleDbConnection cnn;
        CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\asistente de prorrogas\prorrogas.mdb;Persist Security Info=False;";
        cnn = new OleDbConnection(CadenaConexion);

        }
    }
}
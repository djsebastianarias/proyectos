﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Web.Script.Services;
using System.Collections;
using System.Web.Services;
using prorrogas.clases;

namespace prorrogas
{
    public partial class prorrogas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]//método para encontrar la información de radicado.
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public static dp  brtres(string radicado)
        {
            string CadenaConexion;
            string sql;
          
            OleDbConnection cnn;

            CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\asistente de prorrogas\BD\prorrogas.mdb;Persist Security Info=False;";
            cnn = new OleDbConnection(CadenaConexion);
         
            cnn.Open();
            sql = "SELECT planoDP.[Número de Identificación del Cliente], planoDP.[Nombre del cliente] FROM planoDP WHERE planoDP.[Número de Radicado]='" + radicado + "' ";
            OleDbCommand query = new OleDbCommand(sql, cnn);
            OleDbDataReader r = query.ExecuteReader();
            r.Read();

           dp info = new dp();

           info.cedula = r.GetString(0);
           info.nombreCli = r.GetString(1);
           cnn.Close();

           return info;
        }
        [WebMethod]
        public static string guardarDP(string radicadoOcho, string radicadoTres, string radicadoUno, string ente, string IdCliente, string NombCliente, string genero, string medioEnvio, string direccion, string diasPro, string fechpro, string radSuper, string area, string delegado, string estado, string municipio, string causal, string mProrroga, string mreclamo)
        {
            string usuario = Environment.UserName;
            //string usuario = "sebgomez ";
            string CadenaConexion;
            string sql;
            DateTime fecha = DateTime.Now;
            //string fecha = "10/06/2049";
            OleDbConnection cnn;
            CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\asistente de prorrogas\BD\prorrogas.mdb;Persist Security Info=False;";
            cnn = new OleDbConnection(CadenaConexion);

            try
            {
                cnn.Open();
                sql = "INSERT INTO solicitudProrrogas(radicado_ocho,Radicado_tres,Radicado_uno,Ente,id_cliente,nomb_cliente,genero,medio_envio,direccion,dias_pro,fech_pro,radicado_super,area,delegado,estado,municipio,Causal,Mreclamo,Mprorroga,usuario,fecha_registro) VALUES('" + radicadoOcho + "','" + radicadoTres + "','" + radicadoUno + "','" + ente + "','" + IdCliente + "','" + NombCliente + "','" + genero + "','" + medioEnvio + "','" + direccion + "','" + diasPro + "','" + fechpro + "','" + radSuper + "','" + area + "','" + delegado + "','" + estado + "','" + municipio + "','" + causal + "', '" + mreclamo + "','" + mProrroga + "','" + usuario + "','" + fecha + "')  ";
                OleDbCommand ing = new OleDbCommand(sql, cnn);
                ing.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.Write("Ha ocurrido un error en la insercion:" + e);
            }
            finally
            {
                cnn.Close();
            }
            return string.Format("La solicitud de prórroga se ha enviado con exito!");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ListaCheq.clases
{
    public class iniciativa
    {
        public string nombre{get;set;}
        public string pmo { get; set; }
        public string tipo { get; set; }
        public int asignacion { get; set; }
        public string fechaIni { get; set; }
        public string fechaSol { get; set; }
    }


}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Data;

namespace ListaCheq.clases
{
    public class conexion
    {
        static string CadenaConexion;
        static OleDbConnection cnn;
        static OleDbDataAdapter Adaptador;
        static OleDbCommandBuilder Constructor;
    
        public string conectar()
        {
            try{
                CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\Lista de chequeo para asistentes de proceso\BD\lista.mdb;Persist Security Info=False;";
                cnn = new OleDbConnection(CadenaConexion);
                cnn.Open();
                return " Conectado";
            }
            catch
            {
                return " Sin conexión";
            }
            finally
            {
                cnn.Close();
            }
        }


    }
}
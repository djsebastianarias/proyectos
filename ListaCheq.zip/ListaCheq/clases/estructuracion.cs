﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ListaCheq.clases
{
    public class estructuracion
    {
        public int Idiniciativa { get; set; }
        public int Idusuario { get; set; }
        public string reuContEst { get; set; }
        public string reuContAvance { get; set; }
        public string reuContobs { get; set; }
        public string solUsuEst { get; set; }
        public string solUsuAvance { get; set; }
        public string solUsuObs { get; set; }
        public string disConEst { get; set; }
        public string disConAvance { get; set;}
        public string disConobs { get; set; }
        public string contxSecEst { get; set; }
        public string contxSecAvance { get; set; }
        public string contxSecObs { get; set; }
        public string estiTempEst { get; set;}
        public string estiTempAvance { get; set; }
        public string estiTempObs { get; set; }
        public string planEstrcEst { get; set; }
        public string planEstrcAvance { get; set;}
        public string planEstrcObs { get; set; }
    }
}
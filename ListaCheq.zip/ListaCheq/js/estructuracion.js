﻿//$('#iniVig').on('change', function () {
//    var i = $('#iniVig').val()
//    i = JSON.stringify(i);
//    $.ajax({
//        url: "ListaChequeo.aspx/infoBasicaAbierta",
//        type: "GET",
//        data: { "nombre": i },
//        contentType: "application/json;charset=utf-8",
//        dataType: "json",
//        success: function (result) {
//            $.each(result, function (key, item) {
//                //dibujo el resultado de acuerdo a la bd

                
//            });
//        },
//        error: function (result) {
//            alert("ha ocurrido un error" + result.statusText);
//        }
//    });
//})


//guardar parte de estructuracion

jQuery(document).ready(function () {
    $('#guardarEstructuracion').click(function () {
        //Captura de la información
        var nombreIniciativa = $('#Nombre').val();//text
        alert(nombreIniciativa);
        var estadoReuContx = $('#estadoReuContx').val();   //select 
        var porcReuContx = $('#porcReuContx').val();//select
        var obsReuContx = $('#obsReuContx').val();//text
        var estadoSolUs = $('#estadoSolUs').val();//select
        var porcSolUs = $('#porcSolUs').val();//select
        var obsSolUs = $('#obsSolUs').val();//text
        var estadoRevdis = $('#estadoRevdis').val();//select
        var porcRevdis = $('#porcRevdis').val();//select
        var obsRevdis = $('#obsRevdis').val();//text
        var estadoPlani = $('#estadoPlani').val();//select
        var porcPlani = $('#porcPlani').val();//select
        var obsPlani = $('#obsPlani').val();//text
        var estadoContx = $('#estadoContx').val();//select
        var porcContx = $('#porcContx').val();//select
        var obsContx = $('#obsContx').val();//text
        var estadoEsti = $('#estadoEsti').val();//select
        var porcEsti = $('#porcEsti').val();//select
        var obsEsti = $('#obsEsti').val();//text
        
        if (estadoReuContx == null || porcReuContx == null  || estadoSolUs == null || porcSolUs == null || estadoRevdis == null || porcRevdis == null || estadoPlani == null || porcPlani == null || estadoContx == null || porcContx == null || estadoEsti == null || porcEsti==null) {
            alert("Faltan campos por dilgenciar");
        } else {

            sendDataAjax(nombreIniciativa, estadoReuContx, porcReuContx, obsReuContx, estadoSolUs, porcSolUs, obsSolUs, estadoRevdis, porcRevdis, obsRevdis, estadoPlani, porcPlani, obsPlani, estadoContx, porcContx, obsContx, estadoEsti, porcEsti, obsEsti); 

            function sendDataAjax(nombreIniciativa, estadoReuContx, porcReuContx, obsReuContx, estadoSolUs, porcSolUs, obsSolUs, estadoRevdis, porcRevdis, obsRevdis, estadoPlani, porcPlani, obsPlani, estadoContx, porcContx, obsContx, estadoEsti, porcEsti, obsEsti) {
                var actionData = "{'nombreIniciativa': '" + nombreIniciativa + "','estadoReuContx': '" + estadoReuContx + "','porcReuContx': '" + porcReuContx + "','obsReuContx': '" + obsReuContx + "','estadoSolUs': '" + estadoSolUs + "','porcSolUs': '" + porcSolUs + "','obsSolUs': '" + obsSolUs + "','estadoRevdis': '" + estadoRevdis + "','porcRevdis': '" + porcRevdis + "','obsRevdis': '" + obsRevdis + "','estadoContx': '" + estadoContx + "','porcContx': '" + porcContx + "','obsContx': '" + obsContx + "', 'estadoEsti': '" + estadoEsti + "','porcEsti': '" + porcEsti + "','obsEsti': '" + obsEsti + "','estadoPlani': '" + estadoPlani + "','porcPlani': '" + porcPlani + "','obsPlani': '" + obsPlani + "'} ";
                $.ajax(
                    {
                        url: "ListaChequeo.aspx/guardarEstructura",
                        data: actionData,
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        success: function (msg) { alert(msg.d); },
                        error: function (result) {
                            alert("ERRORES " + result.status + ' ' + result.statusText);
                        }
                    });
               // document.getElementById("NombreCrea").value = "";
            
            };
        }

    });
});
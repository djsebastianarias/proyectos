﻿jQuery(document).ready(function () {
    $('#guardar').click(function () {
        var nombre = $('#NombreCrea').val();       
        var pmo = $('#pmoCrea').val();
        var tipoIni = $('#TipoIni').val();
        var asignacion = $('#asignacionCrea').val();        
        var fechaIni = $('#fechaIniCrea').val();
        var fechaSol = $('#fechaFinCrea').val();

        if (nombre == "" || pmo == "" || tipoIni == null || asignacion == "" || fechaIni == "" || fechaSol =="") {
            alert("Faltan campos por dilgenciar");
        } else {
           
            sendDataAjax(nombre, pmo, tipoIni, asignacion, fechaIni, fechaSol);

            function sendDataAjax(nombre, pmo, tipoIni, asignacion, fechaIni, fechaSol) {
                var actionData = "{'nombre': '" + nombre + "','pmo': '" + pmo + "','tipoIni': '" + tipoIni + "','asignacion': '" + asignacion + "','fechaIni': '" + fechaIni + "','fechaSol': '" + fechaSol + "'} ";
                $.ajax(
                    {
                        url: "ListaChequeo.aspx/guardarIniciativa",
                        data: actionData,
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        success: function (msg) { alert(msg.d); },
                        error: function (result) {
                            alert("ERRORES " + result.status + ' ' + result.statusText);
                        }
                    });
                document.getElementById("NombreCrea").value = "";
                document.getElementById("pmoCrea").value = "";
                document.getElementById("TipoIni").value = "";
                document.getElementById("asignacionCrea").value = "";
                document.getElementById("fechaIniCrea").value = "";
                document.getElementById("fechaFinCrea").value = "";              
            };
        }
        
    });
});


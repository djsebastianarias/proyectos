﻿//Cargar de manera automática las funciones de carga de la información básica
$(document).ready(function () {
    cargariniciativas();
    cargariniciativasCerradas();
});
//función para cargar las iniciativas activas que tenga el usuario
function cargariniciativas() {
    $.ajax({
        url: "ListaChequeo.aspx/trabajos",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {                   
            var html = '';
            html += "<option selected disabled>Seleccionar</option>";
            $.each(result, function (key, item) {
                for (var i = 0; i <item.length; i++) {                        
                    html += "<option value='"+item[i]+"'>" + item[i] + "</option>";                   
                }
            });
            $("#iniVig").html(html);
        },
        error: function (result) {
            alert("ha ocurrido un error" + result.statusText);
        }
    });
}
//Función para traer las iniciativas cerradas
function cargariniciativasCerradas() {
    $.ajax({
        url: "ListaChequeo.aspx/iniciativasCerradas",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            var html = '';
            html += "<option selected disabled>Seleccionar</option>";
            $.each(result, function (key, item) {
                for (var i = 0; i < item.length; i++) {
                    html += "<option value='" + item[i] +"'>" + item[i] + "</option>";
                }
            });
            $("#iniCerr").html(html);
        },
        error: function (result) {
            alert("ha ocurrido un error" + result.statusText);
        }
    });
}
/////////////////////////// evento onchange para cargar la información de las iniciativas////////////////////////////////////
// información básica
$('#iniVig').on('change', function () {
    var i = $('#iniVig').val()    
    i = JSON.stringify(i);
    $.ajax({
        url: "ListaChequeo.aspx/infoBasicaAbierta",
        type: "GET",
        data: {"nombre": i},
        contentType: "application/json;charset=utf-8",   
        dataType: "json",
        success: function (result) {
            $.each(result, function (key, item) {
                document.getElementById("Nombre").value = item.nombre;
                document.getElementById("pmo").value = item.pmo; 
                document.getElementById("tipo").value = item.tipo; 
                document.getElementById("asignacion").value = item.asignacion;
                document.getElementById("fechaIni").value = item.fechaIni;
                document.getElementById("fechaFin").value = item.fechaSol; 
                cargariniciativas();
                cargariniciativasCerradas();               
            });
        },
        error: function (result) {
            alert("ha ocurrido un error" + result.statusText);
        }
    });  
})

//Información básica cerrada
$('#iniCerr').on('change', function () {
    var i = $('#iniCerr').val()
    i = JSON.stringify(i);
    $.ajax({
        url: "ListaChequeo.aspx/infoBasicaCerrada",
        type: "GET",
        data: { "nombre": i },
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            $.each(result, function (key, item) {
                document.getElementById("Nombre").value = item.nombre;
                document.getElementById("pmo").value = item.pmo;
                document.getElementById("tipo").value = item.tipo;
                document.getElementById("asignacion").value = item.asignacion;
                document.getElementById("fechaIni").value = item.fechaIni;
                document.getElementById("fechaFin").value = item.fechaSol;
                cargariniciativas();
                cargariniciativasCerradas();
            });
        },
        error: function (result) {
            alert("ha ocurrido un error" + result.statusText);
        }
    });
})  
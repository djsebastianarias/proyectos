﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using System.Data.OleDb;
using System.Web.Script.Services;
using System.Collections;
using ListaCheq.clases;

namespace ListaCheq
{
    public partial class inicio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //método para guardar las iniciativas nuevas
        [WebMethod]
        public static string guardarIniciativa(string nombre, string pmo, string tipoIni, string asignacion, string fechaIni, string fechaSol)
        {
            string usuario = Environment.UserName;
            string CadenaConexion;
            string sql, sqll;
            int resultado = 0;
            OleDbConnection cnn;
            CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\Lista de chequeo para asistentes de proceso\BD\lista.mdb;Persist Security Info=False;";
            cnn = new OleDbConnection(CadenaConexion);

            try
            {
                cnn.Open();
                sql = "SELECT Id_usuario from usuarios where usuario='" + usuario + "' ";
                OleDbCommand query = new OleDbCommand(sql, cnn);
                OleDbDataReader r = query.ExecuteReader();
                r.Read();
                resultado = r.GetInt32(0);
            }
            catch (OleDbException e)
            {
                Console.Write("Error en la busqueda del usuario:" + e);
            }
            finally
            {
                cnn.Close();
            }
            try
            {
                cnn.Open();
                sqll = "INSERT INTO iniciativas(nombre,pmo,tipo,asignacion,fecha_inicial,fecha_est_sol,id_usuario) VALUES('" + nombre + "','" + pmo + "','" + tipoIni + "'," + Convert.ToInt16(asignacion) + ",'" + fechaIni + "','" + fechaSol + "','" + Convert.ToInt32(resultado) + "')  ";
                OleDbCommand ing = new OleDbCommand(sqll, cnn);
                ing.ExecuteNonQuery();
            }
            catch (OleDbException e)
            {
                Console.Write("Ha ocurrido un error en la insercion:" + e);
            }
            finally
            {
                cnn.Close();
            }

            return string.Format("Iniciativa Agregada con éxito: {0}", nombre);
        }
        //método para traer la información de las iniciativas abiertas.
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public static string[] trabajos()
        {
            int i = 0;
            string usuario = Environment.UserName;
            string CadenaConexion;
            string sql, sqll, sqlll;
            int resultado = 0;
            int cuenta = 0;
            OleDbConnection cnn;
            CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\Lista de chequeo para asistentes de proceso\BD\lista.mdb;Persist Security Info=False;";
            cnn = new OleDbConnection(CadenaConexion);

            cnn.Open();
            sql = "SELECT Id_usuario from usuarios where usuario='" + usuario + "' ";
            OleDbCommand query = new OleDbCommand(sql, cnn);
            OleDbDataReader r = query.ExecuteReader();
            r.Read();
            resultado = r.GetInt32(0);
            r.Close();

            sqlll = "SELECT COUNT(iniciativas.nombre) AS cuenta FROM iniciativas WHERE iniciativas.id_usuario=" + resultado + " ";
            OleDbCommand queryyy = new OleDbCommand(sqlll, cnn);
            OleDbDataReader rrr = queryyy.ExecuteReader();
            rrr.Read();

            cuenta = rrr.GetInt32(0);
            rrr.Close();

            sqll = "SELECT iniciativas.nombre FROM iniciativas WHERE iniciativas.id_usuario=" + resultado + " ";
            OleDbCommand queryy = new OleDbCommand(sqll, cnn);
            OleDbDataReader rr = queryy.ExecuteReader();

            int j = cuenta;
            string[] vec = new string[j];
            while (rr.Read())
            {
                vec[i] = rr.GetString(0);
                i++;
            }
            rr.Close();
            cnn.Close();
            return vec;
        }
        //Método para traer las iniciativas cerras
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public static string[] iniciativasCerradas()
        {
            int i = 0;
            string usuario = Environment.UserName;
            string CadenaConexion;
            string sql, sqll, sqlll;
            int resultado = 0;
            int cuenta = 0;
            OleDbConnection cnn;
            CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\Lista de chequeo para asistentes de proceso\BD\lista.mdb;Persist Security Info=False;";
            cnn = new OleDbConnection(CadenaConexion);

            cnn.Open();
            sql = "SELECT Id_usuario from usuarios where usuario='" + usuario + "' ";
            OleDbCommand query = new OleDbCommand(sql, cnn);
            OleDbDataReader r = query.ExecuteReader();
            r.Read();
            resultado = r.GetInt32(0);
            r.Close();

            sqlll = "SELECT COUNT(iniciativasCerradas.nombre) AS cuenta FROM iniciativasCerradas WHERE iniciativasCerradas.id_usuario=" + resultado + " ";
            OleDbCommand queryyy = new OleDbCommand(sqlll, cnn);
            OleDbDataReader rrr = queryyy.ExecuteReader();
            rrr.Read();

            cuenta = rrr.GetInt32(0);
            rrr.Close();

            sqll = "SELECT iniciativasCerradas.nombre FROM iniciativasCerradas WHERE iniciativasCerradas.id_usuario=" + resultado + " ";
            OleDbCommand queryy = new OleDbCommand(sqll, cnn);
            OleDbDataReader rr = queryy.ExecuteReader();

            int j = cuenta;
            string[] vec = new string[j];
            while (rr.Read())
            {
                vec[i] = rr.GetString(0);
                i++;
            }
            rr.Close();
            cnn.Close();
            return vec;
        }
        //Información básica abierta
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public static  iniciativa infoBasicaAbierta(string nombre)
        {         
            string sql, CadenaConexion;
           
            OleDbConnection cnn;
            CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\Lista de chequeo para asistentes de proceso\BD\lista.mdb;Persist Security Info=False;";
            cnn = new OleDbConnection(CadenaConexion);      
            
                cnn.Open();
                sql = "SELECT nombre,pmo,tipo,asignacion,fecha_inicial,fecha_est_sol from iniciativas where nombre='" + nombre + "' ";
                OleDbCommand query = new OleDbCommand(sql, cnn);
                OleDbDataReader r = query.ExecuteReader();
                r.Read();

                iniciativa partes = new iniciativa();

                partes.nombre = r.GetString(0);
                partes.pmo = r.GetString(1);
                partes.tipo = r.GetString(2);
                partes.asignacion = r.GetInt32(3);
                partes.fechaIni = r.GetString(4);
                partes.fechaSol= r.GetString(5);
            cnn.Close();
            return partes;                                   
        }
        //Información básica cerrada
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public static iniciativasCerradas infoBasicaCerrada(string nombre)
        {
            string sql, CadenaConexion;

            OleDbConnection cnn;
            CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\Lista de chequeo para asistentes de proceso\BD\lista.mdb;Persist Security Info=False;";
            cnn = new OleDbConnection(CadenaConexion);

            cnn.Open();
            sql = "SELECT nombre,pmo,tipo,asignacion,fecha_ini,fecha_fin from iniciativasCerradas where nombre='" + nombre + "' ";
            OleDbCommand query = new OleDbCommand(sql, cnn);
            OleDbDataReader r = query.ExecuteReader();
            r.Read();

            iniciativasCerradas partes = new iniciativasCerradas();

            partes.nombre = r.GetString(0);
            partes.pmo = r.GetString(1);
            partes.tipo = r.GetString(2);
            partes.asignacion = r.GetInt32(3);
            partes.fechaIni = r.GetString(4);
            partes.fechaSol = r.GetString(5);
            cnn.Close();
            return partes;
        }
        //búsqueda de la parte de estructuración
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public static estructuracion cargarEstructuracion(string nombre)
        {
            int i = 0;
            string usuario = Environment.UserName;
            string CadenaConexion;
            string sql, sqll, sqlll;
            int resultado = 0;
            int idIni = 0;        
            int cuenta = 0;
            OleDbConnection cnn;
            CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\Lista de chequeo para asistentes de proceso\BD\lista.mdb;Persist Security Info=False;";
            cnn = new OleDbConnection(CadenaConexion);

            cnn.Open();
            sql = "SELECT Id_usuario from usuarios where usuario='" + usuario + "' ";
            OleDbCommand query = new OleDbCommand(sql, cnn);
            OleDbDataReader r = query.ExecuteReader();
            r.Read();
            resultado = r.GetInt32(0);
            r.Close();

            sqll = "SELECT Id_iniciativa from iniciativas where nombre='" + nombre + "' ";
            OleDbCommand queryy = new OleDbCommand(sqll, cnn);
            OleDbDataReader rr = queryy.ExecuteReader();
            rr.Read();
            idIni = rr.GetInt32(0);
            rr.Close();

            sqlll = "SELECT estructuracion.reu_contex__Est, estructuracion.reu_contex__avance, estructuracion.reu_contex__obs, estructuracion.sol_usu_Est, estructuracion.sol_usu_avance, estructuracion.sol_usu_obs, estructuracion.dis_con_Est, estructuracion.dis_con_avance, estructuracion.dis_con_obs, estructuracion.contx_sec_Est, estructuracion.contx_sec_avance, estructuracion.contx_sec_obs, estructuracion.esti_temp_Est, estructuracion.esti_temp_avance, estructuracion.esti_temp_obs,estructuracion.plan_estrc_est,estructuracion.plan_estrc_avance,estructuracion.plan_estrc_obs" +
                "FROM estructuracion " +
                "WHERE estructuracion.Id_iniciativa="+ idIni + " AND estructuracion.id_usuario="+ resultado + " ";

            OleDbCommand queryyy = new OleDbCommand(sqlll, cnn);
            OleDbDataReader rrr = queryyy.ExecuteReader();
            rrr.Read();
            idIni = rrr.GetInt32(0);

            estructuracion estructura = new estructuracion();

            estructura.reuContEst = rrr.GetString(0);
            estructura.reuContAvance = rrr.GetString(1);
            estructura.reuContobs = rrr.GetString(2);
            estructura.solUsuEst = rrr.GetString(3);
            estructura.solUsuAvance = rrr.GetString(4);
            estructura.solUsuObs = rrr.GetString(5);
            estructura.disConEst = rrr.GetString(6);
            estructura.disConAvance = rrr.GetString(7);
            estructura.disConobs = rrr.GetString(8);
            estructura.contxSecEst = rrr.GetString(9);
            estructura.contxSecAvance = rrr.GetString(10);
            estructura.contxSecObs = rrr.GetString(11);
            estructura.estiTempEst = rrr.GetString(12);
            estructura.estiTempAvance = rrr.GetString(13);
            estructura.estiTempObs = rrr.GetString(14);
            estructura.planEstrcEst = rrr.GetString(15);
            estructura.planEstrcAvance = rrr.GetString(17);
            estructura.planEstrcObs = rrr.GetString(18);

            rrr.Close();
            cnn.Close();
            return estructura;
        }

        //Ingresar estructuración
        [WebMethod]
        public static string guardarEstructura(string nombreIniciativa, string estadoReuContx,string porcReuContx, string obsReuContx, string estadoSolUs, string porcSolUs, string obsSolUs,string estadoRevdis, string porcRevdis, string obsRevdis,string estadoContx,string porcContx, string obsContx, string estadoEsti, string porcEsti,string obsEsti, string estadoPlani, string porcPlani, string obsPlani)
        {
            //variables
            string usuario = Environment.UserName;
            string CadenaConexion;
            string sql, sqll,sqlll;
            int idusuario = 0;
            int idIniciativa = 0;
            OleDbConnection cnn;
            CadenaConexion = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Users\sebgomez\Documents\Lista de chequeo para asistentes de proceso\BD\lista.mdb;Persist Security Info=False;";
            cnn = new OleDbConnection(CadenaConexion);
            cnn.Open();
            //consulta para usuario
            sql = "SELECT Id_usuario from usuarios where usuario='" + usuario + "' ";
            OleDbCommand query = new OleDbCommand(sql, cnn);
            OleDbDataReader r = query.ExecuteReader();
            r.Read();
            idusuario = r.GetInt32(0);
            r.Close();

            //Consulta para traer el id de la incitativa
            sqll = "SELECT iniciativas.Id_iniciativa FROM iniciativas WHERE iniciativas.nombre='" + nombreIniciativa + "' ";
            OleDbCommand queryy = new OleDbCommand(sqll, cnn);
            OleDbDataReader rr = queryy.ExecuteReader();
            rr.Read();
            idIniciativa = r.GetInt32(0);
            rr.Close();

            //Ingresar información de estructuración
            
            sqlll = "INSERT INTO estructuracion(Id_iniciativa,id_usuario,reu_contex__Est,reu_contex__avance,reu_contex__obs,sol_usu_Est,sol_usu_avance,sol_usu_obs,dis_con_Est,dis_con_avance,dis_con_obs,contx_sec_Est,contx_sec_avance,contx_sec_obs,esti_temp_Est,esti_temp_avance,esti_temp_obs,plan_estrc_est,plan_estrc_avance,plan_estrc_obs)" +
                " VALUES(" + Convert.ToInt32(idIniciativa) + "," + Convert.ToInt32(idusuario) + ",'" + estadoReuContx + "','" + porcReuContx + "','" + obsReuContx + "','" + estadoSolUs + "','" + porcSolUs + "','" + obsSolUs + "','" + estadoRevdis + "','" + porcRevdis + "','" + obsRevdis + "','" + estadoContx + "','" + porcContx + "','" + obsContx + "','" + estadoEsti + "','" + porcEsti + "','" + obsEsti + "','" + estadoPlani + "','" + porcPlani + "','" + obsPlani + "')  ";
            OleDbCommand ing = new OleDbCommand(sqlll, cnn);
            ing.ExecuteNonQuery();
            cnn.Close();
            return string.Format("Información guardada con éxito");

        }
        //private void ButtondescargaPlanEst_Click(object sender, System.EventArgs e)
        //{
        //    Response.ContentType = "application/ms-excel";
        //    Response.ContentEncoding = System.Text.Encoding.UTF8;
        //    Response.AppendHeader("NombreCabecera", "MensajeCabecera");
        //    Response.TransmitFile(Server.MapPath("D:/Users/sebgomez/Documents/Lista de chequeo para asistentes de proceso/BD/planilla estructuracion/planilla de estructuracion.xlsx"));
        //    Response.End();
        //}

    }
}